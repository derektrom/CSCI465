#ifndef PARSER_H
#define PARSER_H

#include "scanner.h"

/* Parsers our input file */
int pcparse(FILE *fp);

#endif /* PARSER_H */